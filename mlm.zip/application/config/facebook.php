<?php if (!defined('BASEPATH')) exit('No direct script access allowed');


$config['appId']   = '1616925461930268';
$config['secret']  = 'e4f3fc28aed122cb2fc48950563f98cc';

?>
