<style type="text/css">
.title {
	text-align: center;
	font-weight: bold;
}
</style>
<p class="title">Reset Password</p>
<p>Anda telah melakukan reset password. Password baru Anda : </p>

  <p><?= $new_password ?></p>

<p>Silahkan melakukan login kembali</p>

<p>Terima kasih telah mempercayai IOB sebagai partner bisnis Anda untuk meraih impian dan mencapai kesuksesan.</p>
<p>Admin IOB</p>