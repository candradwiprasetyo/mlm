<style type="text/css">
.title {
	text-align: center;
	font-weight: bold;
}
</style>
<p class="title">SELAMAT !</p>
<p>Anda telah mengambil keputusan yang tepat telah bergabung bersama kami di bisnis IOB . Tinggal selangkah lagi untuk memulai menjalankan bisnis dengan potensi penghasilan Jutaan bahkan Milyaran rupiah .</p>

  <p>1. Aktifkan status member Anda menjadi Verified Member dengan cara melakukan pembayaran Rp <?= $total_transfer ?> ke salah satu dari rekening di bawah :</p>

  <li>Bank BCA 1300154197 a/n Muhamad Riduwan Fauzi</li>
  <li>Bank Mandiri 1420014335904 a/n Muhamad Riduwan Fauzi</li>
  <li>Bank BNI 400713530 a/n  Muhamad Riduwan Fauzi</li>

  <p>2. Setelah Anda melakukan pembayaran kemudian silahkan login di Member Area kemudian lakukan konfirmasi sesuai prosedur .</p>
  <p>3. Tunggu proses checking konfirmasi dari Admin IOB 1x24 jam,setelah selesai maka selamat Anda sudah bisa memulai menjalankan bisnis Anda .</p>

<p>Terima kasih telah mempercayai IOB sebagai partner bisnis Anda untuk meraih impian dan mencapai kesuksesan.</p>
<p>Admin IOB</p>