	<footer>
			<div class="container">
				<div class="row">
					<div class="col-md-4">
						<div class="logos-bottom">
                        <img src="<?= base_url() ?>assets/img/logo.png">
                        </div>
						<p>IOB is Your Business Solution</p>
					</div>
					<div class="col-md-4">
						<h4 class="menu-bottom-title">Menu</h4>
						<ul class="menu-bottom-list">
							  <li><a href="<?=site_url('home')?>"><span>Home</span></a></li>
							  <li><a href="<?=site_url('marketing')?>"><span>Marketing & business plan</span></a></li>
							  <li><a href="<?=site_url('register')?>"><span>Join us / Register</span></a></li>
							  <li><a href="<?=site_url('testimonial')?>"><span>Testimonials</span></a></li>
							  <li><a href="<?=site_url('about_us')?>"><span>About us</span></a></li>
							  <li><a href="<?=site_url('contact_us')?>"><span>Contact us</span></a></li>
						</ul>
					</div>
					<div class="col-md-4">
						<h4 class="menu-bottom-title">Kontak Kami</h4>
						<ul class="menu-bottom-list">
							  <li>
							   Investasi Online Bersama ( I O B )
						  </li>
						      <li>
						        Email : <a href="mailto:investasionlinebersama@gmail.com">investasionlinebersama@gmail.com</a>
</li>
						      <li>
						        BBM : 2256BEA1
					      </li>
						      <li>
						        YM : investasiuntung
                              </li>
						</ul>
                        
                       <a href="https://www.facebook.com/Investasi-Online-Bersama-483933108452683/"><div class="icon_footer"><i class="fa fa-facebook fa-1x"></i></div></a>
                        <a href="https://twitter.com/iob4freedom"><div class="icon_footer"><i class="fa fa-twitter fa-1x"></i></div></a>
                         <a href="#"><div class="icon_footer"><i class="fa fa-instagram fa-1x"></i></div></a>
					</div>
					
				</div>
			</div>
		</footer>
		
		
		<!-- load js -->
			<script type="text/javascript" src="<?= base_url('assets/js/jquery/jquery-1.11.3.min.js') ?>"></script>
			<script type="text/javascript" src="<?= base_url('assets/js/bootstrap/bootstrap.min.js') ?>"></script>
			<script type="text/javascript" src="<?= base_url('assets/js/script.js') ?>"></script>
            
        <script type="text/javascript" src="<?= base_url('assets/js/slider/jssor.js') ?>"></script>
    	<script type="text/javascript" src="<?= base_url('assets/js/slider/jssor.slider.js') ?>"></script>
    	<script type="text/javascript" src="<?= base_url('assets/js/slider/slider.js') ?>"></script>
        
        <!-- select -->
		<script type="text/javascript" src="<?= base_url() ?>assets/admin/js/lookup/bootstrap-select.js"></script>
	</body>
</html>