<?php
require_once('header.php');
require_once('content.php');
require_once('footer.php');
?>